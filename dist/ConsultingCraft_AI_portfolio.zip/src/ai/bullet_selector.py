"""
BulletSelector: Agent that selects the most impactful N lines from a list of raw lines
to fit within a specific page budget constraint.
"""
import json
import re
from groq import Groq
from .groq_chat import chat_completion

class BulletSelector:
    def __init__(self, api_key: str, model_name: str = "llama-3.1-8b-instant"):
        self.client = Groq(api_key=api_key) if api_key else None
        self.model_name = model_name

    def select_best_lines(self, raw_lines: list, target_count: int, section_name: str = "") -> list:
        """
        Selects the best `target_count` lines from `raw_lines` based on impact.
        If `len(raw_lines) <= target_count`, returns all lines.
        """
        if not self.client or not raw_lines or len(raw_lines) <= target_count:
            return raw_lines[:target_count]

        numbered_lines = "\n".join([f"{i+1}. {line[:150]}" for i, line in enumerate(raw_lines)])
        
        prompt = f"""You are an MBB resume reviewer. You have a strict space limit.
You must select the {target_count} MOST IMPACTFUL lines from the list below for the "{section_name}" section.

RULES FOR SELECTION:
1. Prioritize lines with numbers, metrics, revenue, percentages, or concrete outcomes.
2. Prioritize leadership, strategic decision-making, and cross-functional impact.
3. Discard vague, repetitive, or purely task-based lines with no business impact.
4. Ensure a diverse representation of skills if possible.

RAW LINES:
{numbered_lines}

Return ONLY a JSON array of exactly {target_count} integers representing the line numbers you selected. 
Example: [1, 4, 5]"""

        try:
            response = chat_completion(
                self.client,
                self.model_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=500,
            )
            text = response.choices[0].message.content
            
            # Parse JSON from response
            try:
                selected_indices = json.loads(text)
            except json.JSONDecodeError:
                match = re.search(r'\[.*\]', text, re.DOTALL)
                if match:
                    selected_indices = json.loads(match.group())
                else:
                    return raw_lines[:target_count]
            
            # Convert to actual lines
            result = []
            seen_indices = set()
            for num in selected_indices:
                idx = int(num) - 1
                if 0 <= idx < len(raw_lines) and idx not in seen_indices:
                    result.append(raw_lines[idx])
                    seen_indices.add(idx)
            
            # Fallback if LLM didn't return enough or returned too many
            if len(result) < target_count:
                result.extend(
                    line
                    for index, line in enumerate(raw_lines)
                    if index not in seen_indices
                )
            if len(result) > target_count:
                result = result[:target_count]
                
            return result

        except Exception as e:
            print(f"BulletSelector error: {e}")
            return raw_lines[:target_count]
