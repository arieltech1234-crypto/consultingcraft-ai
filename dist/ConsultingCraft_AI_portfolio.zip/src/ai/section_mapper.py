"""
SectionMapper: Uses the LLM to map raw Master CV lines into template sections.
Chunks large CVs into batches to stay under token limits.
"""
import json
import re
from groq import Groq
from .groq_chat import chat_completion

# Max lines per LLM call
MAPPER_CHUNK_SIZE = 25


class SectionMapper:
    def __init__(self, api_key: str, model_name: str = "llama-3.1-8b-instant"):
        self.client = Groq(api_key=api_key) if api_key else None
        self.model_name = model_name

    def map_lines_to_sections(self, template_sections: list, raw_lines: list) -> dict:
        """
        Maps each raw Master CV line to the most appropriate template section.
        Chunks large inputs to stay under token limits.
        """
        if not self.client or not raw_lines:
            return {template_sections[0]: raw_lines} if template_sections else {"Experience": raw_lines}

        # Process in chunks and merge results
        all_mappings = {}  # section_name -> [lines]
        
        for chunk_start in range(0, len(raw_lines), MAPPER_CHUNK_SIZE):
            chunk = raw_lines[chunk_start:chunk_start + MAPPER_CHUNK_SIZE]
            chunk_result = self._map_chunk(template_sections, chunk)
            
            for sec_name, sec_lines in chunk_result.items():
                if sec_name not in all_mappings:
                    all_mappings[sec_name] = []
                all_mappings[sec_name].extend(sec_lines)
        
        # Remove empty sections
        return {k: v for k, v in all_mappings.items() if v}

    def _map_chunk(self, template_sections: list, chunk_lines: list) -> dict:
        """Maps a single chunk of lines to sections."""
        numbered_lines = "\n".join([f"{i+1}. {line[:150]}" for i, line in enumerate(chunk_lines)])
        sections_list = ", ".join(template_sections)

        prompt = f"""Classify each line into ONE section: {sections_list}

RULES:
- Education = degrees, university, GPA, academic honors, coursework, school names
- Work Experience = jobs, internships, projects at companies, consulting, client work, deliverables, professional roles
- Extracurriculars & Leadership = clubs, student orgs, volunteering, sports, competitions, non-paid activities
- Skills & Interests = technical skills, tools, languages, certifications, hobbies
- IMPORTANT: Lines mentioning company names, clients, revenue, deliverables, or professional work = Work Experience, NOT Education
- Lines that are just headers/titles/dates with no substance = assign to the section they describe

LINES:
{numbered_lines}

Return ONLY JSON: {{"section_name": [line_numbers]}}
Every number 1-{len(chunk_lines)} must appear exactly once."""

        try:
            response = chat_completion(
                self.client,
                self.model_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=1000,
            )
            text = response.choices[0].message.content

            try:
                mapping = json.loads(text)
            except json.JSONDecodeError:
                match = re.search(r'\{.*\}', text, re.DOTALL)
                if match:
                    mapping = json.loads(match.group())
                else:
                    return {"Work Experience": chunk_lines}

            # Convert line numbers to text
            result = {}
            used_indices = set()
            for section_name, line_numbers in mapping.items():
                if not isinstance(line_numbers, list):
                    continue
                lines_for_section = []
                for num in line_numbers:
                    idx = int(num) - 1
                    if 0 <= idx < len(chunk_lines):
                        lines_for_section.append(chunk_lines[idx])
                        used_indices.add(idx)
                if lines_for_section:
                    result[section_name] = lines_for_section

            # Unmapped lines default to Work Experience
            unmapped = [chunk_lines[i] for i in range(len(chunk_lines)) if i not in used_indices]
            if unmapped:
                result.setdefault("Work Experience", []).extend(unmapped)

            return result

        except Exception as e:
            print(f"SectionMapper chunk error: {e}")
            return {"Work Experience": chunk_lines}
