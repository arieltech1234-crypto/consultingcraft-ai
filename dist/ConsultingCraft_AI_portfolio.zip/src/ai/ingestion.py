"""Private, in-memory document ingestion for CVs and job descriptions."""

from __future__ import annotations

import base64
from io import BytesIO
from pathlib import Path

from groq import Groq


SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".png", ".jpg", ".jpeg"}


class DocumentIngester:
    def __init__(self, api_key: str | None = None, vision_model: str | None = None):
        self.api_key = api_key
        self.vision_model = vision_model

    def extract_text(self, file_path: str) -> str:
        """Extract text from a local file without retaining another copy."""
        path = Path(file_path)
        return self.extract_bytes(path.read_bytes(), path.name)

    def extract_bytes(self, content: bytes, filename: str) -> str:
        """Extract text directly from uploaded bytes without writing to disk."""
        suffix = Path(filename).suffix.lower()
        if suffix not in SUPPORTED_EXTENSIONS:
            raise ValueError(f"Unsupported file format: {suffix or 'unknown'}")
        if not content:
            raise ValueError("The uploaded file is empty.")

        if suffix == ".pdf":
            return self._extract_from_pdf(content)
        if suffix == ".docx":
            return self._extract_from_docx(content)
        return self._extract_from_image(content, suffix)

    @staticmethod
    def _extract_from_pdf(content: bytes) -> str:
        from pypdf import PdfReader

        reader = PdfReader(BytesIO(content))
        text = []
        for page in reader.pages:
            extracted = page.extract_text() or ""
            if extracted.strip():
                text.append(extracted)
        return "\n".join(text)

    @staticmethod
    def _extract_from_docx(content: bytes) -> str:
        import docx

        document = docx.Document(BytesIO(content))
        lines = [
            paragraph.text.strip()
            for paragraph in document.paragraphs
            if paragraph.text.strip()
        ]
        for table in document.tables:
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells if cell.text.strip()]
                if cells:
                    lines.append(" | ".join(cells))
        return "\n".join(lines)

    def _extract_from_image(self, content: bytes, suffix: str) -> str:
        if not self.api_key:
            raise ValueError("An API key is required to read image uploads.")

        client = Groq(api_key=self.api_key)
        vision_model = self.vision_model or self._find_vision_model(client)
        if not vision_model:
            raise ValueError(
                "No vision-capable model is available. Upload a PDF or DOCX instead."
            )

        mime_type = "image/png" if suffix == ".png" else "image/jpeg"
        encoded = base64.b64encode(content).decode("ascii")
        response = client.chat.completions.create(
            model=vision_model,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": (
                                "Extract the text from this resume or job description. "
                                "Return plain text only and preserve section order."
                            ),
                        },
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:{mime_type};base64,{encoded}"},
                        },
                    ],
                }
            ],
            max_tokens=2048,
        )
        return response.choices[0].message.content or ""

    @staticmethod
    def _find_vision_model(client: Groq) -> str | None:
        models = client.models.list().data
        candidates = [
            model.id
            for model in models
            if any(token in model.id.lower() for token in ("vision", "vl", "scout"))
        ]
        return sorted(candidates)[0] if candidates else None
