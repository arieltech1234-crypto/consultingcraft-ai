import re
import time

def chat_completion(client, model, messages, temperature=0.7, max_tokens=2048, max_retries=3, **kwargs):
    kwargs = {k: v for k, v in kwargs.items() if v is not None}
    """Call Groq chat completions, clamping max_tokens if the model rejects it."""
    requested = max_tokens
    attempt = 0
    while attempt < max_retries:
        try:
            print(f"DEBUG: Calling Groq with model {model}...")
            response = client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=requested, **kwargs,
            )
            print(f"DEBUG: Groq response length: {len(response.choices[0].message.content)}")
            return response
        except Exception as e:
            error_str = str(e)
            print(f"DEBUG: Groq API Error: {error_str}")
            match = re.search(
                r"`max_tokens` must be less than or equal to `(\d+)`",
                error_str,
            )
            if match:
                allowed = int(match.group(1))
                if allowed < requested:
                    requested = allowed
                    continue
            if "429" in error_str and attempt < max_retries - 1:
                time.sleep(10 * (attempt + 1))
                attempt += 1
                continue
            raise
