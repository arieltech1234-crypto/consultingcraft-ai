"""ConsultingCraft AI - recruiter-safe Streamlit portfolio application."""

from __future__ import annotations

import copy
import hashlib
import json
import os
import sys
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv


ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
load_dotenv(ROOT / ".env")

from ai.bullet_drafter import BulletDrafter
from ai.bullet_selector import BulletSelector
from ai.constraint_optimizer import ConstraintOptimizer
from ai.ingestion import DocumentIngester
from ai.reference_analyzer import HARVARD_ACTION_VERBS, ReferenceAnalyzer
from ai.section_mapper import SectionMapper
from ai.template_parser import TemplateParser
from app_helpers import (
    build_contact_line,
    meaningful_lines,
    safe_download_stem,
    validate_upload,
)
from demo_content import DEMO_META, DEMO_PROFILE, DEMO_SECTIONS
from layout.generator import CVGenerator
from layout.page_budget import PageBudgetCalculator
from layout.validation import validate_docx_pages


st.set_page_config(
    page_title="ConsultingCraft AI",
    page_icon=":material/description:",
    layout="wide",
)


def configured_api_key(user_key: str = "") -> str:
    if user_key.strip():
        return user_key.strip()
    try:
        secret_key = st.secrets.get("GROQ_API_KEY", "")
    except Exception:
        secret_key = ""
    return secret_key or os.environ.get("GROQ_API_KEY", "")


def resolve_models(api_key: str) -> tuple[str, str | None]:
    from groq import Groq

    available = [model.id for model in Groq(api_key=api_key).models.list().data]
    text_candidates = [
        model
        for model in available
        if not any(token in model.lower() for token in ("whisper", "tts", "vision"))
    ]
    if not text_candidates:
        raise RuntimeError("No text-generation model is available for this API key.")
    preferred = "llama-3.1-8b-instant"
    text_model = preferred if preferred in text_candidates else sorted(text_candidates)[0]
    vision_candidates = [
        model
        for model in available
        if any(token in model.lower() for token in ("vision", "vl", "scout"))
    ]
    return text_model, (sorted(vision_candidates)[0] if vision_candidates else None)


def clear_old_draft_widgets() -> None:
    for key in list(st.session_state):
        if str(key).startswith("draft_"):
            del st.session_state[key]


def run_live_pipeline(
    master_upload,
    reference_uploads,
    structure_upload,
    api_key: str,
    min_words: int,
    max_words: int,
    layout_preferences: dict,
    status,
) -> tuple[dict[str, list[str]], dict]:
    text_model, vision_model = resolve_models(api_key)
    ingester = DocumentIngester(api_key=api_key, vision_model=vision_model)

    master_bytes = master_upload.getvalue()
    validate_upload(master_upload.name, master_bytes)
    master_text = ingester.extract_bytes(master_bytes, master_upload.name)
    raw_lines = meaningful_lines(master_text)
    if not raw_lines:
        raise ValueError("No usable experience lines were found in the master CV.")
    status.write(f"Extracted {len(raw_lines)} evidence lines from the master CV.")

    parser = TemplateParser()
    if structure_upload is not None:
        structure_bytes = structure_upload.getvalue()
        validate_upload(structure_upload.name, structure_bytes)
        template_sections = parser.parse_bytes(structure_bytes, structure_upload.name)
    else:
        template_sections = parser.default_sections()
    status.write(f"Using {len(template_sections)} resume sections.")

    reference_text_parts = []
    for uploaded_file in reference_uploads or []:
        content = uploaded_file.getvalue()
        validate_upload(uploaded_file.name, content)
        reference_text_parts.append(ingester.extract_bytes(content, uploaded_file.name))
    reference_text = "\n".join(reference_text_parts)

    mapper = SectionMapper(api_key=api_key, model_name=text_model)
    mapped = mapper.map_lines_to_sections(template_sections, raw_lines)
    status.write("Mapped evidence to the target resume structure.")

    if reference_text.strip():
        patterns = ReferenceAnalyzer(api_key=api_key, model_name=text_model).analyze(
            reference_text, master_text
        )
        status.write("Analyzed the job description and reference writing style.")
    else:
        patterns = {
            "all_recommended_verbs": HARVARD_ACTION_VERBS[:15],
            "harvard_verbs": HARVARD_ACTION_VERBS,
            "structure_pattern": "Result-Action-Context",
            "tone_analysis": "Concise, quantified, outcome-oriented, and factual.",
            "example_bullets": [],
            "key_themes": [],
        }
        status.write("Applied the default evidence-led consulting style.")

    budget = PageBudgetCalculator(layout_preferences).calculate_budget(template_sections)
    selector = BulletSelector(api_key=api_key, model_name=text_model)
    selected: dict[str, list[str]] = {}
    for section_name, lines in mapped.items():
        target = max(1, budget["per_section_budget"].get(section_name, 2))
        selected[section_name] = selector.select_best_lines(lines, target, section_name)
    selected_count = sum(len(lines) for lines in selected.values())
    status.write(f"Selected {selected_count} high-signal evidence lines for the page budget.")

    drafter = BulletDrafter(api_key=api_key, model_name=text_model)
    drafted: dict[str, list[str]] = {}
    for section_name, lines in selected.items():
        if lines:
            drafted[section_name] = drafter.draft_bullets_batch(
                lines,
                patterns,
                min_words,
                max_words,
                section_context=section_name,
            )

    optimizer = ConstraintOptimizer(
        api_key=api_key, model_name=text_model, max_iterations=3
    )
    optimized = {
        section_name: optimizer.optimize_batch(bullets, min_words, max_words)
        for section_name, bullets in drafted.items()
    }
    failing = sum(
        1
        for bullets in optimized.values()
        for bullet in bullets
        if not min_words <= len(bullet.split()) <= max_words
    )
    status.write(
        "Completed three-pass constraint optimization."
        if failing
        else "All drafted bullets passed the configured word-count constraint."
    )
    return optimized, {
        "source_lines": len(raw_lines),
        "selected_lines": selected_count,
        "model": text_model,
        "reference_files": len(reference_uploads or []),
        "constraint_exceptions": failing,
        "pipeline": [
            "In-memory document ingestion",
            "Section mapping and evidence selection",
            "Reference-pattern analysis",
            "RAC bullet drafting",
            "Constraint optimization",
        ],
    }


for key, value in {
    "draft_sections": None,
    "generation_meta": None,
    "profile": copy.deepcopy(DEMO_PROFILE),
    "generation_id": 0,
    "output_bytes": None,
    "output_hash": None,
    "fit_report": None,
}.items():
    st.session_state.setdefault(key, value)


with st.container(horizontal=True, vertical_alignment="center", gap="small"):
    st.title("ConsultingCraft AI")
    st.badge("Student portfolio prototype", color="green")
st.markdown(
    "An AI-assisted workflow that turns a master CV and target role into a "
    "concise, evidence-led one-page draft."
)

value_columns = st.columns(3)
with value_columns[0].container(border=True, height="stretch"):
    st.markdown("**:material/lock: Private by default**")
    st.caption("Uploads remain in memory for the active browser session.")
with value_columns[1].container(border=True, height="stretch"):
    st.markdown("**:material/rate_review: Human in the loop**")
    st.caption("Every generated bullet is editable before export.")
with value_columns[2].container(border=True, height="stretch"):
    st.markdown("**:material/fit_page: Honest fit check**")
    st.caption("Rendered validation when available; a labeled estimate otherwise.")

with st.sidebar:
    st.header("Build settings")
    run_mode = st.segmented_control(
        "Run mode",
        ["Portfolio demo", "Live AI"],
        default="Portfolio demo",
        required=True,
        key="run_mode",
        width="stretch",
    )
    font_size = st.slider("Font size", 9.0, 11.0, 10.0, 0.5)
    side_margin = st.slider("Side margins (inches)", 0.4, 0.8, 0.55, 0.05)
    vertical_margin = st.slider("Top and bottom margins (inches)", 0.4, 0.8, 0.5, 0.05)
    max_words = int(24 - ((side_margin - 0.5) * 8))
    min_words = max(14, max_words - 5)
    st.caption(f"Target bullet length: {min_words}-{max_words} words")
    st.space("small")
    st.markdown("**Portfolio focus**")
    st.caption("Product discovery · LLM workflow · prioritization · measurable constraints")
    st.caption("v1.0 portfolio build")

layout_preferences = {
    "font_size": font_size,
    "side_margin_inches": side_margin,
    "top_margin_inches": vertical_margin,
    "bottom_margin_inches": vertical_margin,
    "line_spacing_pt": font_size + 1,
    "section_spacing_pt": 6,
    "sub_section_spacing_pt": 2.5,
}

st.subheader("1. Provide evidence and context")
if run_mode == "Portfolio demo":
    st.info(
        "Demo mode uses entirely fictitious candidate data and makes no external API calls.",
        icon=":material/science:",
    )

with st.form("build_inputs"):
    profile_columns = st.columns(2)
    with profile_columns[0]:
        name = st.text_input("Name", value=st.session_state.profile.get("name", ""))
        email = st.text_input("Email", value=st.session_state.profile.get("email", ""))
        location = st.text_input(
            "Location", value=st.session_state.profile.get("location", "")
        )
    with profile_columns[1]:
        phone = st.text_input("Phone", value=st.session_state.profile.get("phone", ""))
        linkedin = st.text_input(
            "LinkedIn", value=st.session_state.profile.get("linkedin", "")
        )
        target_role = st.text_input(
            "Target role", value="AI product manager internship"
        )

    master_upload = None
    reference_uploads = []
    structure_upload = None
    user_api_key = ""
    if run_mode == "Live AI":
        upload_columns = st.columns(2)
        with upload_columns[0]:
            master_upload = st.file_uploader(
                "Master CV",
                type=["docx", "pdf"],
                max_upload_size=8,
                help="Required. Processed in memory and not persisted by the app.",
            )
            structure_upload = st.file_uploader(
                "Optional section structure",
                type=["docx"],
                max_upload_size=8,
                help="Uses the document's section names, not its visual design.",
            )
        with upload_columns[1]:
            reference_uploads = st.file_uploader(
                "Job description or reference resumes",
                type=["docx", "pdf", "png", "jpg", "jpeg"],
                accept_multiple_files=True,
                max_upload_size=8,
            )
            user_api_key = st.text_input(
                "Optional Groq API key",
                type="password",
                help="Used only for this session when no server-side secret is configured.",
            )

    submitted = st.form_submit_button(
        "Generate tailored draft",
        type="primary",
        icon=":material/auto_awesome:",
        width="stretch",
    )

if submitted:
    profile = {
        "name": name.strip(),
        "email": email.strip(),
        "phone": phone.strip(),
        "location": location.strip(),
        "linkedin": linkedin.strip(),
        "target_role": target_role.strip(),
    }
    if not profile["name"]:
        st.error("Add a candidate name before generating a draft.")
    elif run_mode == "Portfolio demo":
        clear_old_draft_widgets()
        st.session_state.profile = profile
        st.session_state.draft_sections = copy.deepcopy(DEMO_SECTIONS)
        st.session_state.generation_meta = copy.deepcopy(DEMO_META)
        st.session_state.generation_id += 1
        st.session_state.output_bytes = None
        st.toast("Fictitious demo draft generated.", icon=":material/check_circle:")
    elif master_upload is None:
        st.error("Upload a master CV to run the live AI workflow.")
    else:
        api_key = configured_api_key(user_api_key)
        if not api_key:
            st.error(
                "Live AI mode requires a Groq API key. Demo mode works without one."
            )
        else:
            with st.status("Running the evidence-to-draft workflow", expanded=True) as status:
                try:
                    sections, meta = run_live_pipeline(
                        master_upload,
                        reference_uploads,
                        structure_upload,
                        api_key,
                        min_words,
                        max_words,
                        layout_preferences,
                        status,
                    )
                    clear_old_draft_widgets()
                    st.session_state.profile = profile
                    st.session_state.draft_sections = sections
                    st.session_state.generation_meta = meta
                    st.session_state.generation_id += 1
                    st.session_state.output_bytes = None
                    status.update(
                        label="Draft ready for human review",
                        state="complete",
                        expanded=False,
                    )
                except Exception as error:
                    status.update(
                        label="Generation stopped safely", state="error", expanded=True
                    )
                    st.error(str(error))

if st.session_state.draft_sections:
    st.subheader("2. Review the evidence-led draft")
    meta = st.session_state.generation_meta or {}
    metric_columns = st.columns(3)
    metric_columns[0].metric("Source evidence", meta.get("source_lines", 0))
    metric_columns[1].metric("Selected bullets", meta.get("selected_lines", 0))
    metric_columns[2].metric(
        "Constraint exceptions", meta.get("constraint_exceptions", 0)
    )

    edited_sections: dict[str, list[str]] = {}
    generation_id = st.session_state.generation_id
    for section_index, (section_name, bullets) in enumerate(
        st.session_state.draft_sections.items()
    ):
        with st.container(border=True):
            st.markdown(f"**{section_name}**")
            edited_sections[section_name] = []
            for bullet_index, bullet in enumerate(bullets):
                edited = st.text_area(
                    f"{section_name} bullet {bullet_index + 1}",
                    value=bullet,
                    height=82,
                    label_visibility="collapsed",
                    key=f"draft_{generation_id}_{section_index}_{bullet_index}",
                )
                edited_sections[section_name].append(edited.strip())

    current_hash = hashlib.sha256(
        json.dumps(edited_sections, sort_keys=True).encode("utf-8")
    ).hexdigest()
    contact_line = build_contact_line(st.session_state.profile)
    structured_data = {
        "name": st.session_state.profile["name"],
        "contact_line": contact_line,
        "experience_buckets": edited_sections,
    }

    with st.container(horizontal=True, horizontal_alignment="right"):
        export_clicked = st.button(
            "Build portfolio-ready DOCX",
            type="primary",
            icon=":material/download:",
        )

    if export_clicked:
        document_bytes = CVGenerator().generate_docx_bytes(
            structured_data, layout_preferences
        )
        calculator = PageBudgetCalculator(layout_preferences)
        estimate = calculator.estimate_fit(
            edited_sections, has_contact=bool(contact_line)
        )
        st.session_state.output_bytes = document_bytes
        st.session_state.output_hash = current_hash
        st.session_state.fit_report = validate_docx_pages(document_bytes, estimate)

    if (
        st.session_state.output_bytes is not None
        and st.session_state.output_hash == current_hash
    ):
        report = st.session_state.fit_report
        if report["fits_one_page"]:
            st.success(
                f"One-page {report['method']} passed at "
                f"{report['utilization']:.0%} estimated page utilization.",
                icon=":material/check_circle:",
            )
        else:
            st.warning(
                f"The current draft is likely {report['estimated_pages']} pages. "
                "Shorten bullets or reduce spacing before sharing.",
                icon=":material/warning:",
            )
        st.caption(report["note"])
        filename = f"{safe_download_stem(st.session_state.profile['name'])}_tailored_CV.docx"
        st.download_button(
            "Download DOCX",
            data=st.session_state.output_bytes,
            file_name=filename,
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            icon=":material/download:",
            width="stretch",
        )

with st.expander("Product case study", icon=":material/account_tree:"):
    st.markdown(
        """
        **Problem:** candidates repeatedly tailor dense CVs to role-specific signals
        while balancing evidence quality and physical page constraints.

        **Product decisions:** keep source documents private by default; separate
        evidence selection from rewriting; require human review; and label page-fit
        estimates instead of presenting them as guarantees.

        **Next experiment:** compare recruiter ratings and factual-error rates across
        manual tailoring, a single-prompt baseline, and this staged workflow.
        """
    )

st.caption(
    "Independent student project. Not affiliated with or endorsed by any consulting firm."
)
